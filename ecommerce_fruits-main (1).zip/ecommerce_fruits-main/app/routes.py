from flask import render_template, redirect, url_for, flash, request
from flask_login import login_user, logout_user, login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
import os

from app import app, db
from app.models import User, Product, Cart
from app.utils import classify_freshness

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        name = request.form["name"]
        email = request.form["email"]
        contact = request.form["contact"]
        role = request.form["role"]
        password = generate_password_hash(request.form["password"], method="scrypt")

        if User.query.filter_by(email=email).first():
            flash("Email already exists!", "danger")
            return redirect(url_for("register"))

        new_user = User(name=name, email=email, contact=contact, password=password, role=role)
        db.session.add(new_user)
        db.session.commit()

        flash("Registration successful! Please login.", "success")
        return redirect(url_for("login"))

    return render_template("register.html")

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form["email"]
        password = request.form["password"]
        user = User.query.filter_by(email=email).first()

        if user and check_password_hash(user.password, password):
            login_user(user)
            return redirect(url_for("dashboard"))

        flash("Invalid credentials!", "danger")
    return render_template("login.html")

@app.route("/logout")
@login_required
def logout():
    logout_user()
    return redirect(url_for("home"))

@app.route("/dashboard")
@login_required
def dashboard():
    if current_user.role == "seller":
        return redirect(url_for("seller_dashboard"))
    elif current_user.role == "customer":
        return redirect(url_for("customer_dashboard"))
    return redirect(url_for("admin_dashboard"))

@app.route("/seller")
@login_required
def seller_dashboard():
    if current_user.role != "seller":
        return redirect(url_for("dashboard"))
    products = Product.query.filter_by(seller_id=current_user.id).all()
    return render_template("seller_dashboard.html", products=products)

@app.route("/add_product", methods=["GET", "POST"])
@login_required
def add_product():
    if request.method == "POST":
        name = request.form["name"]
        price = float(request.form["price"])
        quantity = int(request.form["quantity"])
        image = request.files["image"]

        filename = secure_filename(image.filename)
        image_path = os.path.join("app/static/uploads", filename)
        image.save(image_path)

        freshness = classify_freshness(image_path)

        new_product = Product(name=name, price=price, quantity=quantity, image=filename, freshness=freshness, seller_id=current_user.id)
        db.session.add(new_product)
        db.session.commit()

        flash("Product added successfully!", "success")
        return redirect(url_for("seller_dashboard"))

    return render_template("add_product.html")

@app.route("/customer")
@login_required
def customer_dashboard():
    if current_user.role != "customer":
        return redirect(url_for("dashboard"))
    products = Product.query.all()
    return render_template("customer_dashboard.html", products=products)

@app.route("/add_to_cart", methods=["POST"])
@login_required
def add_to_cart():
    try:
        product_id = request.form.get("product_id")
        quantity = int(request.form.get("quantity", 1))

        if not product_id:
            flash("Invalid product!", "danger")
            return redirect(url_for("customer_dashboard"))

        product = Product.query.get(product_id)

        if not product:
            flash("Product not found!", "danger")
            return redirect(url_for("customer_dashboard"))

        # Check if the product is already in the cart
        existing_cart_item = Cart.query.filter_by(customer_id=current_user.id, product_id=product_id).first()

        if existing_cart_item:
            existing_cart_item.quantity += quantity  # Update quantity
        else:
            new_cart_item = Cart(customer_id=current_user.id, product_id=product_id, quantity=quantity)
            db.session.add(new_cart_item)

        db.session.commit()
        flash("Added to cart!", "success")
        return redirect(url_for("customer_dashboard"))

    except Exception as e:
        flash(f"Error: {str(e)}", "danger")
        return redirect(url_for("customer_dashboard"))


@app.route("/cart")
@login_required
def view_cart():
    # Fetch cart items for the logged-in customer
    cart_items = (
        db.session.query(Cart, Product)
        .join(Product, Cart.product_id == Product.id)
        .filter(Cart.customer_id == current_user.id)
        .all()
    )

    total_price = sum(item.Cart.quantity * item.Product.price for item in cart_items)

    return render_template("cart.html", cart_items=cart_items, total_price=total_price)

@app.route("/update_cart/<int:cart_id>", methods=["POST"])
@login_required
def update_cart(cart_id):
    cart_item = Cart.query.get_or_404(cart_id)
    
    if cart_item.customer_id != current_user.id:
        flash("Unauthorized action.", "danger")
        return redirect(url_for("view_cart"))

    new_quantity = request.form.get("quantity", type=int)

    if new_quantity < 1:
        flash("Quantity must be at least 1.", "warning")
    else:
        cart_item.quantity = new_quantity
        db.session.commit()
        flash("Cart updated successfully!", "success")

    return redirect(url_for("view_cart"))

@app.route("/remove_from_cart/<int:cart_id>")
@login_required
def remove_from_cart(cart_id):
    cart_item = Cart.query.get_or_404(cart_id)
    
    if cart_item.customer_id != current_user.id:
        flash("Unauthorized action.", "danger")
        return redirect(url_for("view_cart"))

    db.session.delete(cart_item)
    db.session.commit()
    flash("Item removed from cart.", "success")

    return redirect(url_for("view_cart"))

@app.route("/checkout")
@login_required
def checkout():
    # Fetch cart items for current user
    cart_items = Cart.query.filter_by(customer_id=current_user.id).all()

    if not cart_items:
        flash("Your cart is empty!", "warning")
        return redirect(url_for("view_cart"))

    # Clear the cart (Simulating order completion)
    for item in cart_items:
        db.session.delete(item)
    
    db.session.commit()

    flash("Order placed successfully! Thank you for shopping.", "success")
    return render_template("checkout.html")

@app.route("/admin_dashboard")
@login_required
def admin_dashboard():
    if current_user.role != "admin":
        return redirect(url_for("home"))

    users = User.query.all()  # Fetch all users
    products = Product.query.all()  # Fetch all products

    return render_template("admin_dashboard.html", users=users, products=products)
