import tensorflow as tf
from tensorflow.keras.models import load_model
from tensorflow.keras.preprocessing import image
import numpy as np
import os

# Load the trained model once at startup
model_path = os.path.join(os.path.dirname(__file__), "model_viskom.h5")
model = load_model(model_path)

# Define class labels
class_labels = ['freshapples', 'rottenapples', 'freshbanana', 'rottenbanana']

def preprocess_image(img_path, target_size=(224, 224)):
    """Preprocesses an image for model prediction."""
    img = image.load_img(img_path, target_size=target_size)
    img_array = image.img_to_array(img)
    img_array = np.expand_dims(img_array, axis=0)  # Expand dims for batch
    img_array = img_array / 255.0  # Normalize pixel values
    return img_array

def classify_freshness(img_path):
    """Classifies an image as fresh/rotten using the loaded model."""
    img_array = preprocess_image(img_path)
    predictions = model.predict(img_array)
    predicted_class = np.argmax(predictions)
    return class_labels[predicted_class]
