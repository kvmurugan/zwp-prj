from app import db, login_manager
from flask_login import UserMixin

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# User Table
class User(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    contact = db.Column(db.String(20), nullable=False)
    password = db.Column(db.String(60), nullable=False)
    role = db.Column(db.String(10), nullable=False)  # "seller" or "customer"

# Product Table
class Product(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    price = db.Column(db.Float, nullable=False)
    quantity = db.Column(db.Integer, nullable=False)
    image = db.Column(db.String(255))  # Path to uploaded image
    freshness = db.Column(db.String(20))  # Fresh/Moderate/Spoiled
    seller_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)

# Cart Table
class Cart(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    customer_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    product_id = db.Column(db.Integer, db.ForeignKey('product.id'), nullable=False)
    quantity = db.Column(db.Integer, nullable=False)
     # Relationships for easier access
    product = db.relationship("Product", backref="cart_items")
    customer = db.relationship("User", backref="cart_items")

# # Orders Table
# class Order(db.Model):
#     id = db.Column(db.Integer, primary_key=True)
#     customer_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
#     total_price = db.Column(db.Float, nullable=False)
#     status = db.Column(db.String(20), default="Pending")  # Pending/Completed
