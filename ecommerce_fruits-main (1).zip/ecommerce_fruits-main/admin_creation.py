from app import app, db  # Import the app instance directly
from app.models import User
from werkzeug.security import generate_password_hash

with app.app_context():  # Set up the application context
    # Check if admin already exists
    admin = User.query.filter_by(email="admin@gmail.com").first()
    
    if not admin:
        admin = User(
            name="Admin",
            email="admin@gmail.com",
            contact="1234567890",
            role="admin",
            password=generate_password_hash("admin@123")
        )
        db.session.add(admin)
        db.session.commit()
        print("✅ Admin user created successfully!")
    else:
        print("⚠️ Admin user already exists.")
